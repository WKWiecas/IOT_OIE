
from lapsolverc import solve_dense

# Needs to be last line
__version__ = '1.1.0'
